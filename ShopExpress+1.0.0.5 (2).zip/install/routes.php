<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/


$route['404_override' ]        = 'error_controller/error_404';
 

$route['store-admin/dashboard'] = "dashboard_controller";

$route['change_guid'] = "frontend_controller/change_product";
//category
$route['store-admin']="login_controller/index";
$route['admin']="login_controller/index";
$route['store-admin/login'] = "login_controller/index";
$route['store-admin/logout'] = "login_controller/logout";


$route['store-admin/allcategory'] = "category_controller/all_category";
$route['store-admin/update_category_status'] = "category_controller/update_category_status";

$route['store-admin/addcategory'] = "category_controller/add_category";
$route['store-admin/editcategory/(:num)'] = "category_controller/edit_category/$1";
$route['store-admin/deletecategory/(:num)'] = "category_controller/delete_category/$1";
$route['store-admin/delete-category'] = "category_controller/ajax_pages_delete";

//tag
$route['store-admin/alltag'] = "tag_controller/all_tag";
$route['store-admin/addtag'] = "tag_controller/add_tag";
$route['store-admin/edittag/(:num)'] = "tag_controller/edit_tag/$1";
$route['store-admin/deletetag/(:num)'] = "tag_controller/delete_tag/$1";
$route['store-admin/delete-tag'] = "tag_controller/ajax_pages_delete";

//Add products
$route['store-admin/search-amazon-page'] = "search_controller/search_amazon_page";
$route['store-admin/search-amazon'] = "search_controller/search_amazon";
$route['store-admin/search-ebay-page'] = "search_controller/search_ebay_page";
$route['store-admin/search-ebay'] = "search_controller/search_ebay";
$route['store-admin/search-aliexpress-page'] = "search_controller/search_aliexpress_page";
$route['store-admin/search-aliexpress'] = "search_controller/search_aliexpress";

//affiliate settings
$route['store-admin/affiliate-settings'] = "setting_controller/affiliate_settings_page";
//$route['store-admin/amazon-settings'] = "setting_controller/amazon_settings";

//All imported products
$route['store-admin/allproducts'] = "all_products_controller/all_products";
$route['store-admin/editproduct/(:num)'] = "all_products_controller/edit_product/$1";
$route['store-admin/deleteproduct/(:num)'] = "all_products_controller/delete_product/$1";
$route['store-admin/delete-product'] = "all_products_controller/ajax_pages_delete";
$route['store-admin/ajaxProductData'] = "all_products_controller/ajaxproduct_data";
$route['store-admin/ajaxProductData/(:num)'] = "all_products_controller/ajaxproduct_data";
$route['store-admin/all_products_ajax_search'] = "all_products_controller/all_products_ajax_search";
//Auto product 
//$route['store-admin/products-automation'] = "products_automation_controller/products_automation";

//automation events
$route['store-admin/allevent'] = "events_automation_controller/all_event";
$route['store-admin/addevent'] = "events_automation_controller/add_event";
$route['store-admin/editevent/(:num)'] = "events_automation_controller/edit_event/$1";
$route['store-admin/deleteevent'] = "events_automation_controller/delete_event";
$route['store-admin/delete-event'] = "events_automation_controller/ajax_pages_delete";
$route['store-admin/get_overview_by_date'] = "stats_controller/get_overview_by_date";



//auto social event settings [ON OFF]
$route['store-admin/instagram-autopost'] = "social_setting_controller/instagram_social";
$route['store-admin/facebook-autopost'] = "social_setting_controller/facebook_social";
$route['store-admin/twitter-autopost'] = "social_setting_controller/twitter_social";

$route['store-admin/instagram-reset'] = "social_setting_controller/instagram_reset";
$route['store-admin/twitter-reset'] = "social_setting_controller/twitter_reset";
$route['store-admin/facebook-reset'] = "social_setting_controller/facebook_reset";

$route['store-admin/social-settings'] = "setting_controller/social_settings_page";

#Add banner
$route['store-admin/banner-ad'] = "ads_controller";
$route['store-admin/adsense-form'] = "ads_controller/adsense_form";
$route['store-admin/banner-image-form'] = "ads_controller/banner_image_form";

/* route by tm*/
 

$route['rss-home'] = "xml_sitemap/rss_category";
$route['rss-feed'] = "xml_sitemap/rss_feed";
$route['rss-feed/(:num)'] = "xml_sitemap/rss_feed_category/$1";
$route['store-admin/change-password'] = "setting_controller/change_password";
$route['store-admin/forgot-password'] = "login_controller/forgot_password";
$route['store-admin/reset-password/(:any)'] = "login_controller/reset_password/$1";

$route['store-admin/ajax_datwise_data'] = "stats_controller/ajax_datwise_data";
$route['store-admin/business-profile'] = "setting_controller/business_profile";
$route['store-admin/get_state']="setting_controller/get_state";
$route['store-admin/get_city']="setting_controller/get_city";
$route['store-admin/ajax_document_add1']="setting_controller/ajax_document_add1";


/*Product status*/
$route['store-admin/product-stats'] = "stats_controller/products";
$route['store-admin/hits-stats'] = "stats_controller/hits";
$route['store-admin/ajax_datwise_hits'] = "stats_controller/ajax_datwise_hits";



$route['store-admin/demo'] = "setting_controller/demo";
$route['store-admin/theme-settings'] = "setting_controller/theme_settings";
$route['store-admin/slider-settings'] = "setting_controller/slider_settings";
$route['store-admin/slider-edit/(:num)'] = "setting_controller/slider_edit/$1";
$route['store-admin/delete-slider'] = "setting_controller/delete_slider";
$route['store-admin/smo-settings'] = "setting_controller/smo_settings";

//automation
$route['store-admin/cron'] = "cron_controller";
//$route['store-admin/update-amazon'] =   "amazon_update_controller";
//$route['store-admin/update-ebay'] =     "ebay_update_controller";
//$route['store-admin/update-aliexpress'] =     "aliexpress_update_controller";
$route['store-admin/update-price'] =     "update_price_controller";

$route['store-admin/autopost-amazon'] = "autopost_amazon_controller";
$route['store-admin/autopost-ebay'] = "autopost_ebay_controller";
$route['store-admin/autopost-aliexpress'] = "autopost_aliexpress_controller";
$route['store-admin/autopost-instagram'] = "autosocial_instagram_controller";
$route['store-admin/autopost-facebook'] = "autosocial_facebook_controller";
$route['store-admin/autopost-twitter'] = "autosocial_twitter_controller";


$route['store-admin/profile-settings'] = "setting_controller/profile_settings";
$route['store-admin/cron-settings'] = "setting_controller/cron_settings";
$route['store-admin/trainings'] = "setting_controller/trainings";


$route['store-admin/stats-overview'] = "stats_controller/stats_overview";
$route['store-admin/stats-overview/(:num)'] = "stats_controller/stats_overview/$1";



$route['store-admin/facebook_redirect'] = "setting_controller/fbuser";
$route['store-admin/social-settings-redirect'] = "setting_controller/redirect_socialSetting";
$route['store-admin/facebook_post'] = "setting_controller/fbpost";


$route['store-admin/terms'] = "terms_controller/terms";
$route['store-admin/privacy-policy'] = "terms_controller/privacy_policy";
$route['store-admin/contact-messeges'] = "terms_controller/contact_messeges";
$route['store-admin/delete-messege'] = "terms_controller/delete_messege";
$route['store-admin/delete-messege1'] = "terms_controller/delete_messege1";


$route['store-admin/license-key'] = "license_controller/license_key";
$route['store-admin/updates'] = "updates/index";
$route['store-admin/install-update'] = "updates/install_update";
$route['store-admin/requirements'] = "requirements/check_requirements";

/* SEO APP*/
$route['store-admin/seo-basic'] = "seo_controller/seo_basic";
$route['store-admin/product-page-seo'] = "seo_controller/product_seo";
$route['store-admin/archive-page-seo'] = "seo_controller/archivepage_seo";
$route['store-admin/site-map'] = "seo_controller/sitemap_xml";
$route['store-admin/sitemap.xml'] = "seo_controller/xml_sitemap";
$route['store-admin/title-settings'] = "seo_controller/title_settings";
$route['store-admin/webmaster-verification'] = "seo_controller/webmaster_verification";
$route['delete-slider'] = "setting_controller/delete_slider";



$route['xml-sitemap'] = "seo_controller/xml_sitemap1";
$route['xmlsitemap'] = "seo_controller/view_sitemap";

/* SEO APP*/
$route['store-admin/smo-basic'] = "smo_controller/smo_basic";
$route['store-admin/design-options'] = "smo_controller/design_options";
$route['store-admin/display-options'] = "smo_controller/display_options";
$route['store-admin/seo-options'] = "seo_controller/reset_seo_options";
$route['store-admin/seo-options1'] = "seo_controller/reset_seo_options1";
$route['store-admin/data_table'] = "seo_controller/datatable";
//front-end
$route['home'] = "frontend_controller/front";
$route['home/(:num)'] = "frontend_controller/front/$1";
$route['get-search-suggestion'] =  "frontend_controller/searchSuggestion";
$route['search'] = "frontend_controller/search";
$route['search/(:num)'] = "frontend_controller/search/$1";
$route['affiliate_hit'] = "frontend_controller/ajax_affiliate_hits";
$route['affiliate_hit1'] = "frontend_controller/ajax_affiliate_hits1";
$route['privacy-policy'] = "frontend_controller/privacy";
$route['contact-us'] = "frontend_controller/contact_us";
$route['terms'] = "frontend_controller/terms";
$route['store-activation'] = "store_controller/store_activation";

$route['category/(:any)'] = "frontend_controller/category_product";
$route['tag/(:any)'] = "frontend_controller/tag_product";
$route['product/(:any)'] = "frontend_controller/single_product";

$route['get_hits_graph'] = "stats_controller/get_hits_graph";

$route['test_mail'] = "terms_controller/my_mail";

$route['default_controller'] = "frontend_controller/front";

$route['(:any)'] = "frontend_controller";


//require_once( BASEPATH .'database/DB'. EXT );
//$db =& DB();
//$query = $db->get( 'app_routes' );
//$result = $query->result();
//foreach( $result as $row )
//{
//    $route[ $row->slug ]                 = $row->controller;
//    $route[ $row->slug.'/:any' ]         = $row->controller;
//    $route[ $row->controller ]           = 'error404';
//    $route[ $row->controller.'/:any' ]   = 'error404';
//}

/* End of file routes.php */
/* Location: ./application/config/routes.php */