var UploadCount=0;
var TotalUploadCount=0;
var ProcessCompleteCount = 0;
var group = false;
var previousHTML;
( function( $ ) {
$( document ).ready(function() {
$('#cssmenu li.has-sub>a').on('click', function(){
		$(this).removeAttr('href');
		var element = $(this).parent('li');
		if (element.hasClass('open')) {
			element.removeClass('open');
			element.find('li').removeClass('open');
			element.find('ul').slideUp();
		}
		else {
			element.addClass('open');
			element.children('ul').slideDown();
			element.siblings('li').children('ul').slideUp();
			element.siblings('li').removeClass('open');
			element.siblings('li').find('li').removeClass('open');
			element.siblings('li').find('ul').slideUp();
		}
	});

	$('#cssmenu>ul>li.has-sub>a').append('<span class="holder"></span>');

	(function getColor() {
		var r, g, b;
		var textColor = $('#cssmenu').css('color');
		textColor = textColor.slice(4);
		r = textColor.slice(0, textColor.indexOf(','));
		textColor = textColor.slice(textColor.indexOf(' ') + 1);
		g = textColor.slice(0, textColor.indexOf(','));
		textColor = textColor.slice(textColor.indexOf(' ') + 1);
		b = textColor.slice(0, textColor.indexOf(')'));
		var l = rgbToHsl(r, g, b);
		if (l > 0.7) {
			$('#cssmenu>ul>li>a').css('text-shadow', '0 1px 1px rgba(0, 0, 0, .35)');
			$('#cssmenu>ul>li>a>span').css('border-color', 'rgba(0, 0, 0, .35)');
		}
		else
		{
			$('#cssmenu>ul>li>a').css('text-shadow', '0 1px 0 rgba(255, 255, 255, .35)');
			$('#cssmenu>ul>li>a>span').css('border-color', 'rgba(255, 255, 255, .35)');
		}
	})();

	function rgbToHsl(r, g, b) {
	    r /= 255, g /= 255, b /= 255;
	    var max = Math.max(r, g, b), min = Math.min(r, g, b);
	    var h, s, l = (max + min) / 2;

	    if(max == min){
	        h = s = 0;
	    }
	    else {
	        var d = max - min;
	        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
	        switch(max){
	            case r: h = (g - b) / d + (g < b ? 6 : 0); break;
	            case g: h = (b - r) / d + 2; break;
	            case b: h = (r - g) / d + 4; break;
	        }
	        h /= 6;
	    }
	    return l;
	}
});
} )( jQuery );

function getCookie(cname){
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length,c.length);
        }
    }
    return "";
}
function AlertAction(text, reload){
	if(reload === undefined) { reload=true; }
	
	$(".alertmsg").addClass("alert-success");
	$(".alertmsg")[0].innerHTML = text;
	
	$("#MyAlert").modal();
	setTimeout(function(){
		$('#MyAlert').modal('hide');
		if(reload){
				//window.location = window.location.href;
		}
		return true;
		
		
	},1000);
}
function GetJsonAPI(array, callback, ReturnData){
	var URL = APIurl;
	array.SessionGroupID = getCookie("SessionGroupID");
	$.post(URL,
	array,
	function(data, status){
			callback(ReturnData);
	});
}

function ID(el){
	return document.getElementById(el);
}
function ClassName(el){
	return document.getElementsByClassName(el);
}
		
function CreateProject(){
var array = {
				'APIkey': APIkey,
				'Action': 'AddProject',
			};
GetJsonAPI(array, CreateProjectDone );		
}

function CreateProjectDone(){
	 AlertAction("<strong>Success!</strong> New project is Created.");
}

function DeleteProject(ProjectID, ReloadURL){
	if(ReloadURL === undefined) { ReloadURL=Domain_url; }
var array = {
				'APIkey': APIkey,
				'Action': 'DeleteProject',
				'ProjectID': ProjectID,
			};
GetJsonAPI(array, DeleteProjectDone, ReloadURL);		
}
function DeleteProjectDone(ReloadURL){
	if(!group){
		AlertAction("<strong>Success!</strong> project(s) is Deleted.");
		setTimeout(function(){
			window.location = ReloadURL;
		},1500);
	}
}
function DeleteVideo(VideoName, ReloadURL){
	if(ReloadURL === undefined) { ReloadURL=Domain_url; }
var array = {
				'APIkey': APIkey,
				'Action': 'DeleteVideo',
				'VideoName': VideoName,
			};	
GetJsonAPI(array, DeleteVideoDone, ReloadURL);		
}
function DeleteVideoDone(ReloadURL){
	if(!group){
		AlertAction("<strong>Success!</strong> Video(s) is Deleted.");
		setTimeout(function(){
			window.location = ReloadURL;
		},1500);
	}
}

function DeleteSeleted(DeleteType){
	SelectItem = ClassName('SelectItem');
	var SelectedList = [];
	for(var i=0; i < SelectItem.length; i++){
		if(SelectItem[i].checked==true){
			SelectedList.push(SelectItem[i].value);
		}
	}
	for(var i=0; i < SelectedList.length; i++){
		group = true;
		if(i == SelectedList.length-1){
			group = false;
		}
		if(DeleteType=="Project"){
			DeleteProject(SelectedList[i], location.href);
		}
		else if(DeleteType=="Video"){
			DeleteVideo(SelectedList[i], location.href);
		}
	}
}



function UploadVideo(ProjectID, SelectID){
	
	
	
	var imageType = ['avi', 'divx', 'flv', 'm4v', 'mkv', 'mov', 'mp4', 'mpeg', 'mpg', 'ogm', 'ogv', 'ogx', 'rm', 'rmvb', 'smil', 'webm', 'wmv', 'xvid'];  
	
	for(var temp=0; temp < SelectID.files.length; temp++){
			var FileName = SelectID.files[temp].name;
			var FileExtension = FileName.substr( (FileName.lastIndexOf('.') +1) );
			
			//console.log(imageType);
		if (-1 == $.inArray(FileExtension, imageType)){
		  alert("not validgf");
		  return false;
		}
	}
		
		
	$('#myModal').modal('show');

	TotalUploadCount = SelectID.files.length;
	
	for (var temp = 0; temp < SelectID.files.length; temp++) {
		$("#UploadTable")
			.append($('<tr>')
			.attr('id', 'Upload_tr'+temp)
				.append($('<td>')
				.attr('style', 'width:110px;')
						.append($('<img>')
						.attr('src', AssetsURL+'images/loader.gif')
						.attr('style', 'width:100px; margin:5px;')
								)
						)
				.append($('<td>')
						.append($('<progress>')	
						.attr('class', 'progressBar')
						.attr('id', 'progressBar'+temp)	
						.attr('value', '0')
						.attr('max', '100')
						.attr('style', 'width:100%;')
						)
						.append($('<input>')
						.attr('id', 'GetUploadID'+temp)	
						.attr('type', 'text')	
						)
						.append($('<input>')
						.attr('id', 'GetTitleID'+temp)	
						.attr('type', 'text')	
						)
						.append($('<p>Video is Uploading Please Wait.</p>')
						.attr('id', 'VideoStatusTextID'+temp)	
						)
				)
			);
	}
	StartUploads(ProjectID, SelectID);
}

function StartUploads(ProjectID, SelectID){
	file = SelectID.files[UploadCount];
	ID("GetTitleID"+UploadCount).value=file.name;
	SingleUploads(ProjectID, SelectID, file);
}

function SingleUploads(ProjectID, SelectID, file){
	var formdata = new FormData();
	formdata.append('video', file);
	formdata.append("Action", 'AddVideo');
	formdata.append("ProjectID", ProjectID);
	formdata.append("APIkey", APIkey);
	var ajax = new XMLHttpRequest();
	ajax.upload.addEventListener("progress", UploadHandler, false);
	ajax.addEventListener("load", function(event){UploadComplete(event, ProjectID, SelectID);}, false);
	ajax.open("POST", "https://videowhizz.saglus.com/API/CodeIgniter/sendjson/");
	ajax.send(formdata);
	console.log(formdata);
}

function UploadHandler(event){ //process progress bar
	var percent = (event.loaded / event.total) * 100;
	ID("progressBar"+UploadCount).value = Math.round(percent);
}

function UploadComplete(event, ProjectID, SelectID){  //afert file upload

	console.log(event.target.responseText);
	VideoName = JSON.parse(event.target.responseText).NewFileName;
	ID("GetUploadID"+UploadCount).value = VideoName;
	ID("VideoStatusTextID"+UploadCount).innerHTML= "Video is Processing";
	ID("progressBar"+UploadCount).value = 0;
	StartCheckProcessStatus(VideoName,UploadCount);
	
	
	UploadCount++;
	if(UploadCount < SelectID.files.length){
		StartUploads(ProjectID, SelectID);
	}
	
}


function StartCheckProcessStatus(VideoName, UploadID){
	var ProcessID = UploadID;

	console.log("t="+TotalUploadCount+'p='+ProcessCompleteCount);
	var URL = "https://videowhizz.saglus.com/API/CodeIgniter/sendjson/";
	$.post(URL,
	{
		'APIkey': APIkey,
		'Action': 'getProcessStatus',
		'VideoName': VideoName,
	},
	function(data, status){
			
			ProcessStatus = JSON.parse(data);
			ID("progressBar"+ProcessID).value = ProcessStatus.getProcessStatus;
			//alert(data);
			if(ProcessStatus.getProcessStatus!=100){
				StartCheckProcessStatus(VideoName, ProcessID);
			}else{
				MoveVideoOnS3(VideoName);
				ProcessCompleteCount++;
			}
	});
}
function MoveVideoOnS3(VideoName){
var array = {
				'APIkey': APIkey,
				'Action': 'MoveVideoOnS3',
				'VideoName': VideoName,
			};
GetJsonAPI(array,UploadDoneAll);		
}
function UploadDoneAll(){
	if(ProcessCompleteCount==TotalUploadCount){
		AlertAction("<strong>Success!</strong> Video(s) is Uploaded.");
	}
}
var SORT_ASC = 1;
function ShortBy(orderby){
	var i = 0;
	var URL = "https://saglus.com/apps/sort.php";
	SORT_ASC = 1-SORT_ASC;
	$.post(URL,
	{
		'jsondata' : JsonToSort,
		'orderby' : orderby,
		'SORT_By_ASC' : SORT_ASC,
	},
	function(data, status){
			JSONobject = JSON.parse(data);
			JSONobject.forEach(function (item, index) {
				$("#ProjectSortby"+item.project_id).attr("data-sortid",i++);
			});		

			var $wrapper = $('.testWrapper');
			$wrapper.find('.sortbox').sort(function (a, b) {
				return +a.dataset.sortid - +b.dataset.sortid;
			})
			.appendTo( $wrapper );			
	});
	
}

function ReplaceVideoUpload(VideoName, SelectID){
		TotalUploadCount =1;
		var temp = 0;
		$("#UploadTable")
			.append($('<tr>')
			.attr('id', 'Upload_tr'+temp)
				.append($('<td>')
				.attr('style', 'width:110px;')
						.append($('<img>')
						.attr('src', AssetsURL+'images/loader.gif')
						.attr('style', 'width:100px; margin:5px;')
								)
						)
				.append($('<td>')
						.append($('<progress>')	
						.attr('class', 'progressBar')
						.attr('id', 'progressBar'+temp)	
						.attr('value', '0')
						.attr('max', '100')
						.attr('style', 'width:100%;')
						)
						.append($('<input>')
						.attr('id', 'GetUploadID'+temp)	
						.attr('type', 'text')	
						)
						.append($('<input>')
						.attr('id', 'GetTitleID'+temp)	
						.attr('type', 'text')	
						)
						.append($('<p>Video is Uploading Please Wait.</p>')
						.attr('id', 'VideoStatusTextID'+temp)	
						)
				)
			);
	ReplaceUploads(VideoName, SelectID);
}
function ReplaceUploads(VideoName, SelectID){
	
	file = SelectID.files[0];
	var formdata = new FormData();
	formdata.append('video', file);
	formdata.append("Action", 'ReplaceVideo');
	formdata.append("VideoName", VideoName);
	formdata.append("APIkey", APIkey);
	var ajax = new XMLHttpRequest();
	ajax.upload.addEventListener("progress", ReplaceUploadHandler, false);
	ajax.addEventListener("load", function(event){ReplaceUploadComplete(event, VideoName, SelectID);}, false);
	ajax.open("POST", "https://videowhizz.saglus.com/API/CodeIgniter/sendjson/");
	ajax.send(formdata);
}
function ReplaceUploadHandler(event){ //process progress bar
	var percent = (event.loaded / event.total) * 100;
	ID("progressBar0").value = Math.round(percent);
}

function ReplaceUploadComplete(event, VideoName, SelectID){  //afert file upload
//	console.log(UploadCount);
	//var VideoName = JSON.parse(event.target.responseText).NewFileName;
	ID("GetUploadID0").value = VideoName;
	ID("VideoStatusTextID0").innerHTML= "Video is Processing";
	ID("progressBar0").value = 0;
	StartCheckProcessStatus(VideoName+'.mp4', 0);
}

function EditVideo(EditType, VideoName){
	if(EditType =="title"){
		var VideoTitle = $("#VID_Title_"+VideoName).html();
		var formvalue = "'title', '"+VideoName+"', this";
		var html = '<input type="text" class="form-control" value="'+VideoTitle+'" onblur="SaveVideo('+formvalue+')" maxlength="200" required="">';
		previousHTML = $("#VID_"+VideoName).html();
		$("#VID_"+VideoName).html(html);
	}
	if(EditType =="desc"){
		var VideoTitle = $("#VID_Desc_"+VideoName).html();
		var formvalue = "'desc', '"+VideoName+"', this";
		var html = '<input type="text" class="form-control" value="'+VideoTitle+'" onblur="SaveVideo('+formvalue+')" maxlength="200">';
		previousHTML = $("#VID_Desc_div"+VideoName).html();
		$("#VID_Desc_div"+VideoName).html(html);
	}
}

function SaveVideo(Savetype, VideoName, elementid){
	var value = elementid.value;
	if(elementid.value.length == 0){
		var formvalue = "'"+Savetype+"', '"+VideoName+"', this";
	$(elementid).parent().html('<input type="text" value="" onblur="SaveVideo('+formvalue+')" maxlength="200" required=""><div style="color:#F00;font-size: 12px;padding-top:5px;" >This field is required!</div>');
		return false;
	}	
	if(elementid.value.length >= 200){
		var formvalue = "'"+Savetype+"', '"+VideoName+"', this";
		$(elementid).parent().html('<input type="text" value="" onblur="SaveVideo('+formvalue+')" maxlength="200" required=""><div style="color:#F00;font-size: 12px;padding-top:5px;" >This field has limit 200!</div>');
		return false;
	}
	if(Savetype =='title'){
		var array = {
					'APIkey': APIkey,
					'Action': 'SaveVideoTitleDesc',
					'VideoName': VideoName,
					'title' : value,
				};
		GetJsonAPI(array, Savechangesdone, {'HTMLDiv' : 'VID_'+VideoName , 'ValueDiv': 'VID_Title_'+VideoName , 'value': value, 'previousHTML':previousHTML});
	}
	if(Savetype =='desc'){
		var array = {
					'APIkey': APIkey,
					'Action': 'SaveVideoTitleDesc',
					'VideoName': VideoName,
					'desc' : value,
				};
		GetJsonAPI(array, Savechangesdone, {'HTMLDiv' : 'VID_Desc_div'+VideoName , 'ValueDiv': 'VID_Desc_'+VideoName , 'value': value, 'previousHTML':previousHTML});
	}
}
function EditProject(EditType, ProjectID){
	console.log(EditType);
	if(EditType =="title"){
		var ProjectTitle = $("#PID_Title_"+ProjectID).html();
		var formvalue = "'"+EditType+"', '"+ProjectID+"', this";
		var html = '<input type="text" class="form-control" value="'+ProjectTitle+'" onblur="SaveProject('+formvalue+')" maxlength="200" required="">';
		previousHTML = $("#PID_"+ProjectID).html();
		$("#PID_"+ProjectID).html(html);
	}
	else if(EditType =="desc"){
		var ProjectTitle = $("#PID_Desc_"+ProjectID).html();
		var formvalue = "'"+EditType+"', '"+ProjectID+"', this";
		var html = '<input type="text" class="form-control" value="'+ProjectTitle+'" onblur="SaveProject('+formvalue+')" maxlength="200">';
		previousHTML = $("#PID_Desc_div"+ProjectID).html();
		$("#PID_Desc_div"+ProjectID).html(html);
	}
	
}

function SaveProject(Savetype, ProjectID, elementid){
		
	var value = elementid.value;
	if(elementid.value.length == 0){
		var formvalue = "'"+Savetype+"', '"+ProjectID+"', this";
		
	$(elementid).parent().html('<input type="text" value="" onblur="SaveProject('+formvalue+')" maxlength="200" required=""><div style="color:#F00;font-size: 12px;padding-top:5px;">This field is required!</div>');
		return false;
	}	
	if(elementid.value.length >= 200){
		var formvalue = "'"+Savetype+"', '"+ProjectID+"', this";
		
		$(elementid).parent().html('<input type="text" value="" onblur="SaveProject('+formvalue+')" maxlength="200" required=""><div style="color:#F00;font-size: 12px;padding-top:5px;">This field has limit 200!</div>');
		return false;
	}
	if(Savetype =='title'){
		var array = {
					'APIkey': APIkey,
					'Action': 'SaveProjectTitleDesc',
					'ProjectID': ProjectID,
					'title' : value,
				};
		GetJsonAPI(array, Savechangesdone, {'HTMLDiv' : 'PID_'+ProjectID , 'ValueDiv': 'PID_Title_'+ProjectID , 'value': value, 'previousHTML':previousHTML});
	}
	if(Savetype =='desc'){
		var array = {
					'APIkey': APIkey,
					'Action': 'SaveProjectTitleDesc',
					'ProjectID': ProjectID,
					'desc' : value,
				};
		
GetJsonAPI(array, Savechangesdone, {'HTMLDiv' : 'PID_Desc_div'+ProjectID , 'ValueDiv': 'PID_Desc_'+ProjectID , 'value': value, 'previousHTML':previousHTML});
	}
}
function Savechangesdone(data){
	$("#"+data.HTMLDiv).html(data.previousHTML);
	$("#"+data.ValueDiv).html(data.value);
	AlertAction("<strong>Success!</strong> Changes are saved", false);

}


