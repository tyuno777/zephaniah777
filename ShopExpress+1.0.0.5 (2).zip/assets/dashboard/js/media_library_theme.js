// JavaScript Document
function show_box(str)
{
document.getElementById('light').style.display='block';
document.getElementById('fade').style.display='block';
document.getElementById('cid').value=str;
document.getElementById("imageInput").disabled = false;
}
function copyToClipboard(elementId) {
document.getElementById('light').style.display='none';
document.getElementById('fade').style.display='none';
document.getElementById("imageInput").disabled = true;
var x=document.getElementById('cid').value;
document.getElementById(x).value=elementId; 

document.getElementById('light').close();
}