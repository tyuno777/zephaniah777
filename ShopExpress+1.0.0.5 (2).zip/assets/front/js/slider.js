function open_panel()
{
slideIt();
var a=document.getElementById("sidebar");
/*a.setAttribute("id","sidebar1");*/
a.setAttribute("onclick","close_panel()");
}

function slideIt()
{
	var slidingDiv = document.getElementById("social-slider");
	var stopPosition = 0;
	
	if (parseInt(slidingDiv.style.left) < stopPosition )
	{
		slidingDiv.style.left = parseInt(slidingDiv.style.left) + 2 + "px";
		setTimeout(slideIt, 1);	
	}
}
	
function close_panel(){
slideIn();
a=document.getElementById("sidebar");
/*a.setAttribute("id","sidebar");*/
a.setAttribute("onclick","open_panel()");
}

function slideIn()
{
	var slidingDiv = document.getElementById("social-slider");
	var stopPosition = -105;
	
	if (parseInt(slidingDiv.style.left) > stopPosition )
	{
		slidingDiv.style.left = parseInt(slidingDiv.style.left) - 2 + "px";
		setTimeout(slideIn, 1);	
	}
}