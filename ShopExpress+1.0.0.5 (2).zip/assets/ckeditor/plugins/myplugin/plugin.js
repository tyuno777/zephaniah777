﻿CKEDITOR.plugins.add('myplugin',   //name of our plugin
{    
    requires: ['dialog'], //requires a dialog window
    init:function(a) {
  var b="myplugin";
  var c=a.addCommand(b,new CKEDITOR.dialogCommand(b));
  c.modes={wysiwyg:1,source:1}; //Enable our plugin in both modes
  c.canUndo=true;
 
  //add new button to the editor
  a.ui.addButton("myplugin",
  {
   label:'Insert Media',
   command:b,
   icon:this.path+"images/icon.png"   //path of the icon
  });
  CKEDITOR.dialog.add(b,this.path+"images/save.png") //path of our dialog file
 }
});