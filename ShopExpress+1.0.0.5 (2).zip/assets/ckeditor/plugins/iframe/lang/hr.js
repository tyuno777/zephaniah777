/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'hr', {
	border: 'Prikaži okvir IFrame-a',
	noUrl: 'Unesite URL iframe-a',
	scrolling: 'Omogući trake za skrolanje',
	title: 'IFrame svojstva',
	toolbar: 'IFrame'
} );
