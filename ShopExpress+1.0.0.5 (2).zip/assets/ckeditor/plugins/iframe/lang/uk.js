/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'uk', {
	border: 'Показати рамки фрейму',
	noUrl: 'Будь ласка введіть URL посилання для IFrame',
	scrolling: 'Увімкнути прокрутку',
	title: 'Налаштування для IFrame',
	toolbar: 'IFrame'
} );
