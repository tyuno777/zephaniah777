/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'he', {
	border: 'הראה מסגרת לחלון',
	noUrl: 'יש להכניס כתובת לחלון.',
	scrolling: 'אפשר פסי גלילה',
	title: 'מאפייני חלון פנימי (iframe)',
	toolbar: 'חלון פנימי (iframe)'
} );
