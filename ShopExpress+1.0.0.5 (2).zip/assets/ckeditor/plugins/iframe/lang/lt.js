/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'lt', {
	border: 'Rodyti rėmelį',
	noUrl: 'Nurodykite iframe nuorodą',
	scrolling: 'Įjungti slankiklius',
	title: 'IFrame nustatymai',
	toolbar: 'IFrame'
} );
