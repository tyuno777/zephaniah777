/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'id', {
	border: 'Tampilkan Batas Bingkai',
	noUrl: 'Please type the iframe URL', // MISSING
	scrolling: 'Aktifkan Scrollbar',
	title: 'IFrame Properties', // MISSING
	toolbar: 'IFrame'
} );
