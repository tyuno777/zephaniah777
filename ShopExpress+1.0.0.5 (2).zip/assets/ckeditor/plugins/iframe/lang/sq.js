/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'sq', {
	border: 'Shfaq kufirin e kornizës',
	noUrl: 'Ju lutemi shkruani URL-në e iframe-it',
	scrolling: 'Lejo shiritët zvarritës',
	title: 'Karakteristikat e IFrame',
	toolbar: 'IFrame'
} );
